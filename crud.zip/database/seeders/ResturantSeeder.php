<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;
class ResturantSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {


        DB::table('resturants')->insert(
            [
                [
                    'name'=>'Xiwang',
                    'address'=>'Johar Town',
                    'phone'=>'03008484848',
                ],
                [
                    'name'=>'Kfc',
                    'address'=>'Iqbal Town Lahore',
                    'phone'=>'03008484848',
                ],
                [
                    'name'=>'Fri Chicks',
                    'address'=>'Town Ship',
                    'phone'=>'03008484848',
                ],
                [
                    'name'=>'Mcdonald',
                    'address'=>'Fortress Stadium',
                    'phone'=>'03008484848',
                ],
                [
                    'name'=>'Dera Restaurant',
                    'address'=>'Johar Town',
                    'phone'=>'03008484848',
                ],

            ]
        );
    }
}
