<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('categories')->insert(
            [
                [
                    'name'=>'Chinese',
                    'resturant_id'=>'1',
                    'status'=>'1',

                ],
                [
                    'name'=>'Italian',
                    'resturant_id'=>'2',
                    'status'=>'1',
                ],
                [
                    'name'=>'Fast Food',
                    'resturant_id'=>'3',
                    'status'=>'1',
                ],
                [
                    'name'=>'Pizza',
                    'resturant_id'=>'4',
                    'status'=>'0',
                ],
                [
                    'name'=>'Continental',
                    'resturant_id'=>'5',
                    'status'=>'1',
                ],

            ]
        );
    }
}
