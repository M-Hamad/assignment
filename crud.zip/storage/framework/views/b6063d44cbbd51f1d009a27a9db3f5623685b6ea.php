<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <title>Resturants Assignment</title>
</head>
<body>

<h1 style="text-align: center;">Laravel Assignment</h1>
    <div class="container mt-4">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>
        <form action="<?php echo e(route('submit.form')); ?>" method="post" enctype="multipart/form-data" class="needs-validation shadow p-3" novalidate>
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="item_resturant_id">Resturants <span class="text-danger">*</span></label>
                <select name="item_resturant_id" id="item_resturant_id" class="form-control">
                    <option value="">--Select any Resturants--</option>
                    <?php $__currentLoopData = $resturants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$resturants_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value='<?php echo e($resturants_data->id); ?>'><?php echo e($resturants_data->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="item_category_id">Category <span class="text-danger">*</span></label>
                <select name="item_category_id" id="item_category_id" class="form-control">
                    <option value="">--Select any category--</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value='<?php echo e($cat_data->id); ?>'><?php echo e($cat_data->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" class="form-control" placeholder="Enter Your Name" value="<?php echo e(old('name')); ?>" required>
                <?php echo $__env->make('error.error', ['filed' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="invalid-feedback">
                    Name Required
                </div>
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="price" name="price" class="form-control" placeholder="Enter Your Price" value="<?php echo e(old('price')); ?>" required>
                <?php echo $__env->make('error.error', ['filed' => 'price'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="invalid-feedback">
                    Price
                </div>
            </div>
            <div class="form-group">
                <label for="price">Import Resturant File</label>
                <input type="file" name="file" class="form-control" >
                <?php echo $__env->make('error.error', ['filed' => 'file'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="invalid-feedback">
                    File
                </div>
            </div>



            <button class="btn btn-success btn-sm" type="submit">Submit</button>
        </form>
        <br>
            <a href="<?php echo e(route('view.resturants')); ?>" class="btn btn-primary btn-block">View All Items</a>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\crud\resources\views/welcome.blade.php ENDPATH**/ ?>