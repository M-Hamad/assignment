<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <title>All Users</title>
</head>
<body>
    <div class="container mt-4">
        <a href="<?php echo e(URL::previous()); ?>" class="btn btn-warning btn-sm">Go Back</a><br><br>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>id</th>
                    <th>name</th>
                    <th>email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($val->id); ?></td>
                    <td><?php echo e($val->name); ?></td>
                    <td><?php echo e($val->email); ?></td>
                    <td>
                        <a type="button" class="text-info" data-toggle="modal" data-target="#exampleModal<?php echo e($val->id); ?>">Edit</a>
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal<?php echo e($val->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('edit.user')); ?>" method="post" class="needs-validation shadow p-3" novalidate>
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="name">Name</label>
                                                <input type="text" class="form-control" name="name" value="<?php echo e($val->name); ?>" required>
                                                <?php echo $__env->make('error.error', ['filed' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <div class="invalid-feedback">
                                                    Name Required
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">email</label>
                                                <input type="text" class="form-control" name="email" value="<?php echo e($val->email); ?>" required>
                                                <?php echo $__env->make('error.error', ['filed' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <div class="invalid-feedback">
                                                    Email Required
                                                </div>
                                            </div>
                                            <input type="hidden" name="id" value="<?php echo e($val->id); ?>">
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary">Save changes</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        | <a onclick="return confirm('Do you really want to delete User?')" href="<?php echo e(route('delete.user',$val->id)); ?>" class="text-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH E:\highapp\validation\resources\views/resturants.blade.php ENDPATH**/ ?>
