<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <title>LARAVEL</title>
</head>
<body>
    <div class="container mt-4">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>
        <form action="<?php echo e(route('submit.form')); ?>" method="post" enctype="multipart/form-data" class="needs-validation shadow p-3" novalidate>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" class="form-control" placeholder="Enter Your Name" value="<?php echo e(old('name')); ?>" required>
                <?php echo $__env->make('error.error', ['filed' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="invalid-feedback">
                    Name Required
                </div>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control" placeholder="Enter Your Email" value="<?php echo e(old('email')); ?>" required>
                <?php echo $__env->make('error.error', ['filed' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="invalid-feedback">
                    Email Required
                </div>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter Your Password" value="<?php echo e(old('password')); ?>" required>
                <?php echo $__env->make('error.error', ['filed' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="invalid-feedback">
                    Password Required
                </div>
            </div>
            <button class="btn btn-success btn-sm" type="submit">Submit</button>
        </form>
        <br>
            <a href="<?php echo e(route('view.users')); ?>" class="btn btn-primary btn-block">View All Users</a>
    </div>
</body>
</html>
<?php /**PATH E:\highapp\validation\resources\views/welcome.blade.php ENDPATH**/ ?>