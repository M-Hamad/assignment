<?php if($errors->has($filed)): ?>
    <div class="text-danger w-100">
        <span class=""><?php echo e($errors->first($filed)); ?></span>
    </div>
<?php endif; ?>
<?php /**PATH E:\highapp\validation\resources\views/error/error.blade.php ENDPATH**/ ?>