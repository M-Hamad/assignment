<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <script src="{{ asset('js/jquery.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
    <title>Resturants Assignment</title>
</head>
<body>

<h1 style="text-align: center;">Laravel Assignment</h1>
    <div class="container mt-4">
        @if(Session::has('success'))
            <div class="alert alert-success">{{ Session::get('success') }}</div>
        @endif
        @if(Session::has('error'))
            <div class="alert alert-danger">{{ Session::get('error') }}</div>
        @endif
        <form action="{{ route('submit.form') }}" method="post" enctype="multipart/form-data" class="needs-validation shadow p-3" novalidate>
            @csrf

            <div class="form-group">
                <label for="item_resturant_id">Resturants <span class="text-danger">*</span></label>
                <select name="item_resturant_id" id="item_resturant_id" class="form-control">
                    <option value="">--Select any Resturants--</option>
                    @foreach($resturants as $key=>$resturants_data)
                        <option value='{{$resturants_data->id}}'>{{$resturants_data->name}}</option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="item_category_id">Category <span class="text-danger">*</span></label>
                <select name="item_category_id" id="item_category_id" class="form-control">
                    <option value="">--Select any category--</option>
                    @foreach($categories as $key=>$cat_data)
                        <option value='{{$cat_data->id}}'>{{$cat_data->name}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" class="form-control" placeholder="Enter Your Name" value="{{ old('name') }}" required>
                @include('error.error', ['filed' => 'name'])
                <div class="invalid-feedback">
                    Name Required
                </div>
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="price" name="price" class="form-control" placeholder="Enter Your Price" value="{{ old('price') }}" required>
                @include('error.error', ['filed' => 'price'])
                <div class="invalid-feedback">
                    Price
                </div>
            </div>
            <div class="form-group">
                <label for="price">Import Resturant File</label>
                <input type="file" name="file" class="form-control" >
                @include('error.error', ['filed' => 'file'])
                <div class="invalid-feedback">
                    File
                </div>
            </div>



            <button class="btn btn-success btn-sm" type="submit">Submit</button>
        </form>
        <br>
            <a href="{{ route('view.resturants') }}" class="btn btn-primary btn-block">View All Items</a>
    </div>
</body>
</html>
