<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <script src="{{ asset('js/jquery.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
    <title>All Users</title>
</head>
<body>
<div class="container mt-4">
    <a href="{{ URL::previous() }}" class="btn btn-warning btn-sm">Go Back</a><br><br>
    @if(Session::has('success'))
        <div class="alert alert-success">{{ Session::get('success') }}</div>
    @endif
    @if(Session::has('error'))
        <div class="alert alert-danger">{{ Session::get('error') }}</div>
    @endif
    <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th>id</th>
            <th>name</th>
            <th>email</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        @foreach($users as $val)
            <tr>
                <td>{{ $val->id }}</td>
                <td>{{ $val->name }}</td>
                <td>{{ $val->email }}</td>
                <td>
                    <a type="button" class="text-info" data-toggle="modal" data-target="#exampleModal{{ $val->id }}">Edit</a>
                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal{{ $val->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="{{ route('edit.user') }}" method="post" class="needs-validation shadow p-3" novalidate>
                                    @csrf
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control" name="name" value="{{ $val->name }}" required>
                                            @include('error.error', ['filed' => 'name'])
                                            <div class="invalid-feedback">
                                                Name Required
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="email">email</label>
                                            <input type="text" class="form-control" name="email" value="{{ $val->email }}" required>
                                            @include('error.error', ['filed' => 'email'])
                                            <div class="invalid-feedback">
                                                Email Required
                                            </div>
                                        </div>
                                        <input type="hidden" name="id" value="{{ $val->id }}">
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    | <a onclick="return confirm('Do you really want to delete User?')" href="{{ route('delete.user',$val->id) }}" class="text-danger">Delete</a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
</body>
</html>
