<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Item;
use App\Models\Resturant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Imports\UsersImport;
use Maatwebsite\Excel\Facades\Excel;
class ItemController extends Controller
{

    private $item;
    public function __construct(Item $item)
    {
        $this->item = $item;
    }

    public function submitForm(Request $request)
    {
//        $this->validate($request,
//            [
//                'item_resturant_id' => 'required',
//                'item_category_id' => 'required',
//                'name' => 'required',
//                'price'=>'required',
//            ]);


        if($request->hasFile('file')) {
            $newItem = '';
            $file = $request->file('file');
            $file_name = $file->getClientOriginalName();
            $name = $file->getClientOriginalName();
            $image['filePath'] = $name;
            $file->move(public_path() . '/docs/', $file_name);
            $filepath = (public_path() . '/docs/' . $file_name);

            $rows = Excel::toArray(new UsersImport, $filepath);

            ////////File Uplaod Code start member Here////////

            $in_row_records = $rows[0];
            $count_other_column = 0;
            $count = 0;
            $datavalue = 0;


//            dd($cat);
            $arr = [];

            for ($row_three = 0; $row_three < count($in_row_records); $row_three++) {


                $insertData = array(
                    //"hash"=>md5(rand(1111,5555). rand(6666,9999).time()),
                    "name" => $rows[$count][$row_three][0],
                    "price" => $rows[$count][$row_three][1],
                    "item_resturant_id" => $rows[$count][$row_three][2],
                    "item_category_id" => $rows[$count][$row_three][3]
                );


                if($this->item->where('item_category_id', $insertData['item_category_id'] )->exists() && $this->item->where('name', $insertData['name'] )->exists()){
                    // your code...

                }
                else{

                    $newItem = $this->item->createItem($insertData);
                }

            }


            if($newItem){
                Session::flash('success','Record Insert Successfully!');
                return back();
            }else{
                Session::flash('success','Record Insert Successfully!');
                return back();
            }
        }
           else{
                $formData = $request->all();

                $newItem = $this->item->createItem($formData);

            }
    }

    public function viewResturants()
    {
        $users = $this->item->getItem();
        $resturants=Resturant::all();
        $categories=Category::all();

        return view('resturants',compact('users','resturants','categories'));
    }

    public function deleteUsers($id)
    {
        $delete = $this->item->deleteItem($id);
        if($delete)
        {
            Session::flash('success','Record Delete Successfully!');
            return back();
        }else{
            Session::flash('error','Something Wrong Try Again Later!');
            return back();
        }
    }

    public function editUsers(Request $request)
    {

        $this->validate($request,
            [
                'item_resturant_id' => 'required',
                'item_category_id' => 'required',
                'name' => 'required',
                'price'=>'required',
            ]);
        $id = $request->id;
        $data = $request->except('id','_token');

        $update = $this->item->updateItem($id,$data);
        if($update){
            Session::flash('success','Record Update Successfully!');
            return back();
        }else{
            Session::flash('error','Something Wrong Try Again Later!');
            return back();
        }
    }
}
