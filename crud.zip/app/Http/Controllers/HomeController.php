<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class HomeController extends Controller
{
    private $user;
    public function __construct(User $user)
    {
        $this->user = $user;
    }

    public function submitForm(Request $request)
    {
        $this->validate($request,
            [
                'name' => 'required|min:2',
                'email' => 'required|email',
                'password' => 'required|min:5',
            ]);
        $formData = $request->all();
        $formData['password'] = Hash::make($request->password);
        $newUser = $this->user->createUser($formData);
        if($newUser){
            Session::flash('success','Record Insert Successfully!');
            return back();
        }else{
            Session::flash('error','Something Wrong Try Again Later!');
            return back();
        }
    }

    public function viewUsers()
    {
        $users = $this->user->getUsers();
        return view('users',compact('users'));
    }

    public function deleteUsers($id)
    {
        $delete = $this->user->deleteUser($id);
        if($delete)
        {
            Session::flash('success','Record Delete Successfully!');
            return back();
        }else{
            Session::flash('error','Something Wrong Try Again Later!');
            return back();
        }
    }

    public function editUsers(Request $request)
    {
        $this->validate($request,
            [
                'id' => 'required',
                'name' => 'required|min:2',
                'email' => 'required|email',
            ]);
        $id = $request->id;
        $data = $request->except('id','_token');
        $update = $this->user->updateUser($id,$data);
        if($update){
            Session::flash('success','Record Update Successfully!');
            return back();
        }else{
            Session::flash('error','Something Wrong Try Again Later!');
            return back();
        }
    }
}
