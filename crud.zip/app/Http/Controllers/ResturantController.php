<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Resturant;
use Illuminate\Http\Request;

class ResturantController extends Controller
{

    public function index()
    {

        $resturants=Resturant::all();
        $categories=Category::all();

        return view('welcome',compact('resturants','categories'));
    }
}
