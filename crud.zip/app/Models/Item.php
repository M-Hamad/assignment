<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;



class Item extends Model
{
    use HasFactory;

    protected $fillable=['item_resturant_id','item_category_id','name','price','created_at','updated_at'];


    public function category()
    {

        return $this->belongsTo(Category::class);

    }

    public function resturant()
    {

        return $this->belongsTo(Resturant::class);

    }

    public function createItem($data)
    {

        $qry = Item::create($data);
        return $qry;
    }

    public function getItem($id = null)
    {
        if($id){
            $qry = Item::find($id);
        }else{
            $qry = Item::all();
        }
        return $qry;
    }

    public function deleteItem($id)
    {
        $resturant = Item::find($id);
        $qry = $resturant->delete();
        return $qry;
    }

    public function updateItem($id,$data)
    {
        $resturant = Item::find($id);
        $qry = $resturant->update($data);
        return $qry;
    }
}
