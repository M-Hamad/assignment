<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Resturants;

class Resturant extends Model
{
    use HasFactory;

    protected $fillable=['name','category_id','address','phone','created_at','updated_at'];

    public function categories(){

        return $this->hasMany(Category::class);
    }
    public function Item(){
        return $this->hasMany(Item::class);
    }




}
